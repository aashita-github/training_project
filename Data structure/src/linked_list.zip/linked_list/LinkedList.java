package linked_list;

import java.util.Iterator;

public class LinkedList<T> implements Iterable<T> {
Node<T> head;


int size;
public Node<T> getHead() {
	return head;
}
public void setHead(Node<T> head) {
	this.head = head;
}
public int getSize() {
	return size;
}
public void setSize(int size) {
	this.size = size;
}
public void push(T x) {
	Node<T> node=new Node<>(x);
	node.next=head;
    head=node;
	
}
public void insertAfter(Node<T> prev,T x) {
if(prev==null) {
	System.out.print("Previous node cannot be return");
	return;
}

Node<T> node=new Node<>(x);
node.next=prev.next;
prev.next=node;


}
public void append(T x) {
Node<T> node=new Node<>(x);
  if(head==null) {
  head=new Node<>(x);
  return;
}
node.next=null;
Node<T> last=head;
while(last.next!=null) {
	last=last.next;
	
}
last.next=node;
return;
}

public void printLinkedList() {

	Node<T> nNode=head;
	while(nNode!=null) {
		System.out.print(nNode.data+" ");
		nNode=nNode.next;
		
	}
}

public void deleteKeyNode(T x) {
	setSize(size()-1);
	 Node<T> temp = head, prev = null;
	if (temp != null && temp.data.equals(x)) {
        head = temp.next; 
        return;
    }

    
    while (temp != null && !temp.data.equals(x)) {
        prev = temp;
        temp = temp.next;
    }

    
    if (temp == null)
        return;

   
    prev.next = temp.next;

}
public void insertNth(T data, int position) {

    Node<T> node=new Node<>(data);



    if (this.head == null) {
        //if head is null and position is zero then exit.
        if (position != 0) {
            return;
        } else { //node set to the head.
            this.head = node;
        }
    }

    if (head != null && position == 0) {
        node.next= this.head;
        this.head = node;
        return;
    }

    Node<T> current = this.head;
    Node<T> previous = null;

    int i = 0;

    while (i < position) {
        previous = current;
        current = current.next;

        if (current == null) {
            break;
        }

        i++;
    }

    node.next = current;
    previous.next = node;
}
public void printMiddle()
{
    Node<T> slow = head;
    Node<T> fast = head;
    if (head != null)
    {
        while (fast!= null && fast.next != null)
        {
            fast= fast.next.next;
            slow = slow.next;
        }
        System.out.println("\n The middle element is " +
                            slow.data );
    }
}
public Node<T> reverseLinkedList(Node<T> headref) {
	Node<T> current=headref;
	Node<T> previous=null;
	Node<T> nextNode=null;
	while(current!=null) {
		nextNode=current.next;
		current.next=previous;
		previous=current;
		current=nextNode;
		
	}
	headref=previous;
	return headref;
}

public void deleteNodeAtPosition(int pos) {
	setSize(size()-1);
	Node<T> temp=head;

	if(pos==0) {
		head=temp.next;
		return;
	}
	int count=0;
	while(temp!=null && count<(pos-1)) {
		count+=1;
		temp=temp.next;
		
	}
	temp.next=temp.next.next;
}

public int size() {
	int length=0;
	Node<T> nNode=head;
	while(nNode!=null) {
		length++;
		nNode=nNode.next;
}
	return length;

}
public Iterator<T> iterator() {
	// TODO Auto-generated method stub
	return new listIterator<T>(this);
}

}