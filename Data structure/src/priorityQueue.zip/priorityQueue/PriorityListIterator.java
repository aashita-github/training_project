package priorityQueue;

import java.util.Iterator;
import java.util.NoSuchElementException;


public class PriorityListIterator implements Iterator<Object>{
	private int currentIndex=0;
	int SIZE=0;
	int[] ARRAY;
	public PriorityListIterator(int size,int[] array) {
		
		SIZE=size;
		ARRAY=array;
		
	}
	@Override
	public boolean hasNext() {
	
		if(currentIndex<SIZE)
			return true;
		else
			return false;
		
	}
	@Override
	public Object next() {
	int x;
	 
	if(currentIndex<SIZE) {
		x=ARRAY[currentIndex];
		currentIndex++;
		return x;
	}
	else
		throw new NoSuchElementException();

		}


}

	
