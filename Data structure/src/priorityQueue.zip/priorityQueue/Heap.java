package priorityQueue;


public class Heap{

      public static void sort(int arr[])
	    {
	        int n = arr.length;
	 
	        // Build heap (rearrange array)
	        for (int i = n / 2 ; i>=0; i--)
	            heapify(arr, n, i);
	
	        }
	        
	    // To heapify a subtree rooted with node i which is
	    // an index in arr[]. n is size of heap
	 public static void heapify(int arr[], int n, int i)
	    {
	        int largest = i; // Initialize largest as root
	        int l = 2 * i ; // left = 2*i 
	        int r = 2 * i + 1; // right = 2*i + 1
	 
	        // If left child is larger than root
	        if (l < n && arr[l] > arr[largest])
	            largest = l;
	 
	        // If right child is larger than largest so far
	        if (r < n && arr[r] > arr[largest])
	            largest = r;
	 
	        // If largest is not root
	        if (largest != i) {
	            int swap = arr[i];
	            arr[i] = arr[largest];
	            arr[largest] = swap;
	 
	            // Recursively heapify the affected sub-tree
	            heapify(arr, n, largest);
	        }
	    }
	 public static int deleteNode(int heap[],int size) {
		 int lastElement = heap[size - 1];
		  
	        // Replace root with first element
	        heap[0] = lastElement;
	  
	        // Decrease size of heap by 1
	        size= size - 1;
	  
	        // heapify the root node
	        heapify(heap, size, 0);
	  
	        // return new size of Heap
	        return size;
	        
		  }
	 
	    /* A utility function to print array of size n */
	  public  static void printArray(int arr[],int size)
	    {
	        int n = size;
	        for (int i = 0; i < n; ++i)
	            System.out.print(arr[i] + " ");
	        System.out.println("\n");
	    }	
	  public static void printReverseArray(int array[], int size) {
		    for (int i=size-1;i>=0;i--){
		      System.out.print(array[i] + " ");
		    }
		    System.out.println("\n");
		  }
	  public static int highestPriorityElement(int array[]) {
			return array[0];
			
		}
}
