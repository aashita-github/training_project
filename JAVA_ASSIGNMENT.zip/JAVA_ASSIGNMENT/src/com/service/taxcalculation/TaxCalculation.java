package com.service.taxcalculation;

import com.model.Item;

/**
 * @author
 *
 */
public class TaxCalculation {
	// function to figure out type of tax to be implied on items
	public static Item calculateTaxForItem(Item itemObject) {

		if (itemObject.getType().equals(TaxTypeConstants.RAW)) {
			return calculateRawItemTax(itemObject);
		} else if (itemObject.getType().equals(TaxTypeConstants.MANUFACTURED)) {
			return calculateManufacturedItemTax(itemObject);
		} else if (itemObject.getType().equals(TaxTypeConstants.IMPORTED)) {
			return calculateImportedItemTax(itemObject);
		}

		return null;
	}

	/**
	 * @param itemObject
	 * @return
	 */
	private static Item calculateRawItemTax(Item itemObject) {
		double tax = 0.125 * itemObject.getPrice();
		itemObject.setTax(tax);
		return itemObject;
	}

	/**
	 * @param itemObject
	 * @return
	 */
	private static Item calculateManufacturedItemTax(Item itemObject) {
		double tax = 0.125 * itemObject.getPrice() + 0.02 * (itemObject.getPrice() + (0.125 * itemObject.getPrice()));
		itemObject.setTax(tax);
		return itemObject;
	}

	/**
	 * @param itemObject
	 * @return
	 */
	private static Item calculateImportedItemTax(Item itemObject) {
		double duty = 0.1 * itemObject.getPrice();
		double t = 0.125 * itemObject.getPrice();
		double s = 0;
		s = duty + t + itemObject.getPrice();
		double sur;
		if (s <= 100)
			sur = 5;
		else if (s > 100 && s <= 200)
			sur = 10;
		else
			sur = 0.05 * s;
		double tax = 0.1 * itemObject.getPrice() + sur;

		itemObject.setTax(tax);

		return itemObject;
	}
}
