package com.model;

/**
 * @author
 *
 */
public class Item {

	private String name;
	private int price;
	private int quantity;
	private String type;
	private double tax;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public double getTax() {
		return tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		type = type.toLowerCase();
		if (type.equals("raw") || type.equals("maufactured") || type.equals("imported"))
			this.type = type;
		else
			this.type = "Not Valid";
	}

	@Override
	public String toString() {
		return "Item [name=" + name + ", price=" + price + ", quantity=" + quantity + ", type=" + type + ", tax=" + tax
				+ "]";
	}

	public void printItemDetails(Item i) {
		System.out.println("Name: " + i.getName());
		System.out.println("Item Price: " + i.getPrice());
		System.out.println("Sales Tax Liability: " + i.tax);
		System.out.println("Final Price: " + (i.tax + i.getPrice()));
	}
}
