package priorityQueue;
import java.util.Scanner;



import java.util.Iterator;
public class PriorityQueue implements Iterable<Object>{
	public static Scanner obj=new Scanner(System.in);
	public static int array[];
	public static int size;
	public static int[] getArray() {
		return array;
	}
	public static void setArray(int[] array) {
		PriorityQueue.array = array;
	}
	public static int getSize() {
		return size;
	}
	public static void setSize(int size) {
		PriorityQueue.size = size;
	}
	public static void enqueue() {
		int n;
		System.out.print("Enter Initial Size of Priority Queue: ");
		 
        while(true)
		{
    	try {
		 n=Integer.parseInt(obj.next());
		break;
    	}
    	catch(NumberFormatException e) {
    		System.out.println("Enter a number!");
    		continue;
    	}
		}
		array=new int[n];
		 PriorityQueue.setSize(n);
		 System.out.println("Enter ELements of Priority Queue: ");
		for(int i=0;i<n;i++) {
			
			int input=obj.nextInt();
		
     		array[i]=(input);
     		
		}
		Heap.sort(array);
	}
	public static void printHeap() {
		int size=array.length;
		 System.out.println("Priority Queue: ");
		 Heap.printArray(array,size);
	}
	public static void dequeue() {
		int size=getSize();
		 size=Heap.deleteNode(array,size);
		 Heap.printArray(array,size);
		 PriorityQueue.setSize(size);
	}
	
	public static void printReverseHeap() {
		 System.out.println("Priority Queue in Reverse: ");
		    Heap.printReverseArray(array,PriorityQueue.getSize());
	}
	public static int peek() {
		return Heap.highestPriorityElement(array);
	}
	public static void priorityQueueConatins(int key) {
		boolean ans=false; 
		for(int i=0;i<size;i++) {
			 if(key==array[i])
				 ans=true;
		 }
		
		 if (ans==true)
          System.out.println("The list contains "+key+"\n");
	     else
	       System.out.println("The list does not contains "+key+"\n");
	}
	public Iterator<Object> iterator() {
		// TODO Auto-generated method stub
		return new PriorityListIterator(PriorityQueue.getSize(),PriorityQueue.getArray());
	}
	
public static void main(String args[]) {
	int key,option;
	PriorityQueue prio=new PriorityQueue();
	while(true)
    { System.out.println("\nEnter yours choice \n1.ENQUEUE         2.DEQUEUE HIGHEST PRIORITY");
    System.out.println("3.PEEK HIGHEST PRIORITY 4.CONATIN    5.SIZE   ");
    System.out.println("6.REVERSE QUEUE         7.ITERATOR   8.EXIT");
   
    
    while(true)
	{
	try {
	 option=Integer.parseInt(obj.next());
	break;
	}
	catch(NumberFormatException e) {
		System.out.println("Enter a number!");
		continue;
	}
	}
    switch(option)
    { case 1:
    	PriorityQueue.enqueue();
       	PriorityQueue.printHeap();
    	break;
    case 2:
    	System.out.println("After deleting the Highest Priority element--> ");
    	PriorityQueue.dequeue();
      	break;
    
    case 3:
    	System.out.println("Peek of Highest Priority Element: "+PriorityQueue.peek()+"\n");
    	break;
    case 4:
    	System.out.print("Enter an Element to check: ");
   	 
        while(true)
    	{
    	try {
    	key=Integer.parseInt(obj.next());
    	break;
    	}
    	catch(NumberFormatException e) {
    		System.out.println("Enter a number!");
    		continue;
    	}
    	}
    	PriorityQueue.priorityQueueConatins(key);
        break;
    case 5:
    	System.out.println("Size Of Queue: "+PriorityQueue.getSize()+"\n");
    	break;
    case 6:
    	PriorityQueue.printReverseHeap();
         break;
    case 7:
    	PriorityListIterator iterator = (PriorityListIterator) prio.iterator();
    	System.out.println("******Iterate over the Queue while iterator is moving******");
    	
    	while (iterator.hasNext()) {

    		System.out.print(iterator.next()+" ");
    		
    	}
    	System.out.println();
     	
        break;	
   
    
    case 8:
    	System.exit(0);
    default:System.out.println("Wrong option");
    }
    }
   
  }
}
