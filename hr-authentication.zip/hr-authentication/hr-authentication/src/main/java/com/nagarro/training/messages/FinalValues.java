package com.nagarro.training.messages;


public class FinalValues {
	public static final String USERNAME = "username";
	public static final String PASSWORD = "password";
	public static final String ERROR = "error";
	public static final String PHONE = "phone";
	public static final String CPASSWORD = "cpassword";
	public static final String AUTHORIZED = "authorized";
	public static final String USER = "user";
	public static final String EMPLOYEES = "employeeDtos";
	public static final String URL = "http://localhost:8097/employees/";
	public static final String EMPLOYEE = "employeeDto";
	public static final String CSVFILE = "Employees.csv";
}
