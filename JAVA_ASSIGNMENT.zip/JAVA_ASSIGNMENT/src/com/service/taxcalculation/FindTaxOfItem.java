package com.service.taxcalculation;

import java.util.ArrayList;
import java.util.Scanner;

import com.model.Item;


/**
 * @author
 *
 */
public class FindTaxOfItem {

	private static Scanner obj = new Scanner(System.in);

	public static void main(String[] args) {
		ArrayList<Item> itemList = new ArrayList<Item>();
		char op;

		do {
			Item itemObject = scanValuesForItem();
			// Do Tax Calculation for Item Object
			Item itemObjectWithTax = TaxCalculation.calculateTaxForItem(itemObject);
			if (itemObjectWithTax != null)
				itemList.add(itemObjectWithTax);
			System.out.println("Do you want to enter details of any other item (y/n):");
			op = obj.nextLine().charAt(0);

		} while (op == 'y' || op == 'Y');

		Item item = new Item();
		for (Item d : itemList) {
			item.printItemDetails(d);
			System.out.println();

		}

	}

	public static Item scanValuesForItem() {
		Item itemObject = new Item();
		System.out.println("Enter Name");
		itemObject.setName(obj.nextLine());
		System.out.println("Enter Price");
		try {
			itemObject.setPrice(Integer.parseInt(obj.nextLine()));
		} catch (NumberFormatException e) {
			System.out.println("Enter a number!");
			itemObject.setPrice(Integer.parseInt(obj.nextLine()));

		}
		System.out.println("Enter Quantity");
		try {
			itemObject.setPrice(Integer.parseInt(obj.nextLine()));
		} catch (NumberFormatException e) {
			System.out.println("Enter a number!");
			itemObject.setPrice(Integer.parseInt(obj.nextLine()));
		}
		System.out.println("Enter Type");
		itemObject.setType(obj.nextLine());

		return itemObject;

	}
}
