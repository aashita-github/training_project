package com.service.taxcalculation;

/**
 * @author
 *
 */
public class TaxTypeConstants {

	public static final String RAW = "raw";
	public static final String IMPORTED = "imported";
	public static final String MANUFACTURED = "manufactured";

}
